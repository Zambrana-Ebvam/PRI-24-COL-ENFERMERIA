﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

namespace ProgramColegioEnfermeras.Models;

public class Userr
{
    public int Id { get; set; }

    public string UserName { get; set; } = null!;

    public string Password { get; set; } = null!; // Confirmamos que sea string

    public string Rol { get; set; } = null!;

    public DateTime RegistrationDate { get; set; }

    public DateTime? UpdateDate { get; set; }

    public byte? State { get; set; }

    public virtual Nurse? IdNavigation { get; set; }
}


// Helper para hashing
public static class HashHelper
{
    public static byte[] ComputeSha256Hash(string rawData)
    {
        using (SHA256 sha256 = SHA256.Create())
        {
            return sha256.ComputeHash(Encoding.UTF8.GetBytes(rawData));
        }
    }

    public static bool VerifyPassword(string enteredPassword, byte[] storedPasswordHash)
    {
        var enteredPasswordHash = ComputeSha256Hash(enteredPassword);
        return storedPasswordHash.SequenceEqual(enteredPasswordHash);
    }
}
