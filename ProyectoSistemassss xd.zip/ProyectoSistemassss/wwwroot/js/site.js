﻿var currentZoom = 16;

function zoomIn() {
    currentZoom++;
    updateMapZoom();
}

function zoomOut() {
    currentZoom--;
    updateMapZoom();
}

function updateMapZoom() {
    var mapIframe = document.getElementById('mapIframe');
    mapIframe.src = 'https://www.bing.com/maps/embed?h=400&w=1600&cp=-17.402379~-66.158036&lvl=' + currentZoom + '&typ=d&sty=r&src=SHELL&FORM=MBEDV8';
}

function searchLocation() {
    var query = document.getElementById('searchBox').value;
    if (query) {
        alert('Buscar la dirección: ' + query);
        // Aquí va la lógica de búsqueda de la ubicación
    }
}
