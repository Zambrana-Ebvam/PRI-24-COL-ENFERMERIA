﻿using Microsoft.EntityFrameworkCore;
using ProyectoSistemassss.Models;
using System.Collections.Generic;

namespace ProyectoSistemassss.Data
{
    public class AppDbContext : DbContext
    {

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<School> Schools { get; set; }
        public DbSet<Province> Provinces { get; set; }
    }
}
