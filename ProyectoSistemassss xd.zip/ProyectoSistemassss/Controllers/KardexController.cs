﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProyectoSistemassss.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;
using System.Threading.Tasks;

namespace ProyectoSistemassss.Controllers
{
    public class KardexController : Controller
    {
        private readonly BdUnivalleEnfermerasContext _context;

        public KardexController(BdUnivalleEnfermerasContext context)
        {
            _context = context;
        }

        public IActionResult CRUD()
        {
            ViewBag.EstudentId = new SelectList(_context.Students, "Id", "FirstName");
            ViewBag.NurseId = new SelectList(_context.Nurses, "Id", "Names");
            return View();
        }

        [HttpGet]
        public async Task<JsonResult> GetAllKardexes()
        {
            var kardexes = await _context.Kardex
                .Include(k => k.IdStudentNavigation)
                .Include(k => k.IdNurseNavigation)
                .Where(k => k.State == 1)
                .Select(k => new {
                    id = k.Id,
                    height = k.Height,
                    weight = k.Weight,
                    oxygenLevel = k.OxygenLevel,
                    description = k.Description,
                    temperature = k.Temperature,
                    respiratoryRate = k.RespiratoryRate,
                    bloodPressure = k.BloodPressure,
                    derivation = k.Derivation,
                    studentName = k.IdStudentNavigation.FirstName,
                    nurseName = k.IdNurseNavigation.Names
                }).ToListAsync();

            return Json(kardexes);
        }

        [HttpPost]
        public IActionResult Create(Kardex kardex)
        {
            if (ModelState.IsValid)
            {
                kardex.State = 1;
                _context.Kardex.Add(kardex);
                _context.SaveChanges();
                return Json(new { success = true, message = "Kardex creado exitosamente." });
            }
            return Json(new { success = false, message = "Datos no válidos." });
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var kardex = _context.Kardex.Find(id);
            if (kardex == null)
            {
                return Json(new { success = false, message = "Kardex no encontrado." });
            }
            return Json(kardex);
        }

        [HttpPost]
        public IActionResult Edit(Kardex kardex)
        {
            if (ModelState.IsValid)
            {
                var existingKardex = _context.Kardex.Find(kardex.Id);
                if (existingKardex == null)
                {
                    return Json(new { success = false, message = "Kardex no encontrado." });
                }

                // Actualizar propiedades del Kardex existente
                existingKardex.Height = kardex.Height;
                existingKardex.Weight = kardex.Weight;
                existingKardex.OxygenLevel = kardex.OxygenLevel;
                existingKardex.Description = kardex.Description;
                existingKardex.Temperature = kardex.Temperature;
                existingKardex.RespiratoryRate = kardex.RespiratoryRate;
                existingKardex.BloodPressure = kardex.BloodPressure;
                existingKardex.Derivation = kardex.Derivation;
                existingKardex.IdStudent = kardex.IdStudent;
                existingKardex.IdNurse = kardex.IdNurse;

                _context.SaveChanges();
                return Json(new { success = true, message = "Kardex actualizado correctamente." });
            }
            return Json(new { success = false, message = "Datos no válidos." });
        }

        [HttpPost]
        public IActionResult DeleteLogical(int id)
        {
            var kardex = _context.Kardex.Find(id);
            if (kardex == null)
            {
                return Json(new { success = false, message = "Kardex no encontrado." });
            }

            kardex.State = 0; 
            _context.Kardex.Update(kardex);
            _context.SaveChanges();

            return Json(new { success = true, message = "Kardex eliminado correctamente." });
        }

    }
}
