﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProyectoSistemassss.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ProyectoSistemassss.Controllers
{
    public class PrescriptionController : Controller
    {
        private readonly BdUnivalleEnfermerasContext _context;

        public PrescriptionController(BdUnivalleEnfermerasContext context)
        {
            _context = context;
        }

        public IActionResult CRUD()
        {
            ViewBag.MedicineId = new SelectList(_context.Medicines.ToList(), "Id", "Name");
            ViewBag.StudentId = new SelectList(_context.Students.ToList(), "Id", "FirstName");
            ViewBag.NurseId = new SelectList(_context.Nurses.ToList(), "Id", "FirstName");
            return View();
        }

        [HttpGet]
        public async Task<JsonResult> GetAllPrescriptions()
        {
            var prescriptions = await _context.Prescriptions
                .Include(p => p.Medicine)
                .Include(p => p.Student)
                .Include(p => p.Nurse)
                .Where(p => p.Status == 1)
                .Select(p => new {
                    id = p.Id,
                    dosage = p.Dosage,
                    frecuency = p.Frecuency,
                    instructions = p.Instructions,
                    medicineName = p.Medicine.Name,
                    studentName = p.Student.FirstName,
                    nurseName = p.Nurse.FirstName
                }).ToListAsync();

            return Json(prescriptions);
        }

        [HttpPost]
        public IActionResult Create(Prescription prescription)
        {
            if (ModelState.IsValid)
            {
                prescription.Status = 1;
                _context.Prescriptions.Add(prescription);
                _context.SaveChanges();

                return Json(new { success = true });
            }
            return Json(new { success = false, message = "Datos no válidos." });
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var prescription = _context.Prescriptions.Find(id);
            if (prescription == null)
            {
                return NotFound();
            }
            return Json(prescription);
        }

        [HttpPost]
        public IActionResult Edit(Prescription prescription)
        {
            if (ModelState.IsValid)
            {
                var existingPrescription = _context.Prescriptions.Find(prescription.Id);
                if (existingPrescription == null)
                {
                    return Json(new { success = false, message = "Prescripción no encontrada." });
                }

                existingPrescription.Dosage = prescription.Dosage;
                existingPrescription.Frecuency = prescription.Frecuency;
                existingPrescription.Instructions = prescription.Instructions;
                existingPrescription.MedicineId = prescription.MedicineId;
                existingPrescription.StudentId = prescription.StudentId;
                existingPrescription.NurseId = prescription.NurseId;
                existingPrescription.StarDate = prescription.StarDate;
                existingPrescription.EndDate = prescription.EndDate;

                _context.SaveChanges();
                return Json(new { success = true, message = "Prescripción actualizada correctamente." });
            }

            return Json(new { success = false, message = "Datos no válidos." });
        }

        [HttpPost]
        public IActionResult DeleteLogical(int id)
        {
            var prescription = _context.Prescriptions.Find(id);
            if (prescription == null)
            {
                return NotFound();
            }

            prescription.Status = 0;
            _context.Prescriptions.Update(prescription);
            _context.SaveChanges();

            return Json(new { success = true });
        }
    }
}
