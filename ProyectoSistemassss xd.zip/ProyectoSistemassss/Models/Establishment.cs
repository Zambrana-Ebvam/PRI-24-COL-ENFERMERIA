﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ProyectoSistemassss.Models;

public partial class Establishment
{

    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public byte Id { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio")]
    [MaxLength(60)]
    public string Name { get; set; } = null!;

    [Required(ErrorMessage = "El horario es obligatorio")]
    [MaxLength(30)]
    public string Schedule { get; set; } = null!;

    [Required(ErrorMessage = "La zona es obligatoria")]
    [MaxLength(50)]
    public string Zone { get; set; } = null!;

    [Required(ErrorMessage = "La latitud es obligatoria")]
    public double Latitude { get; set; }

    [Required(ErrorMessage = "La longitud es obligatoria")]
    public double Longitude { get; set; }

    [MaxLength(10)]
    public string Phone { get; set; } = null!;

    [Required(ErrorMessage = "El director es obligatorio")]
    [MaxLength(60)]
    public string Director { get; set; } = null!;

    public DateTime RegisterDate { get; set; }

    public DateTime? LastUpdate { get; set; }

    public int? UserId { get; set; }

    public byte Status { get; set; }

    [Required]
    public byte ProvinceId { get; set; }

    [ForeignKey("ProvinceId")]
    public virtual Province? Province { get; set; }

    public virtual ICollection<Student> Students { get; set; } = new List<Student>();
}
