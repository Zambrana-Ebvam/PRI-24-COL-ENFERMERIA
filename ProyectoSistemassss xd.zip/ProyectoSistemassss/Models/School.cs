﻿namespace ProyectoSistemassss.Models
{
    public class School
    {
        public byte Id { get; set; }
        public string Name { get; set; }
        public string Schedule { get; set; }
        public string Zone { get; set; }
        public float Latitude { get; set; }
        public float Longitude { get; set; }
        public string Phone { get; set; }
        public string Director { get; set; }
        public DateTime RegisterDate { get; set; }
        public DateTime? LastUpdate { get; set; }
        public int UserId { get; set; }
        public byte Status { get; set; }

        // Foreign Key
        public byte ProvinceId { get; set; }
        public Province Province { get; set; }
    }
}
