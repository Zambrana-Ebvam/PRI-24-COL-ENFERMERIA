﻿using System;
using System.Collections.Generic;

namespace ProyectoSistemassss.Models;

public partial class Nurse
{
    public int Id { get; set; }

    public string Names { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string? MiddleName { get; set; }

    public string Gender { get; set; } = null!;

    public DateOnly Birthdate { get; set; }

    public string Ci { get; set; } = null!;

    public string Cellphone { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Address { get; set; } = null!;

    public string? CodeSedes { get; set; }

    public string? Specialty { get; set; }

    public DateTime RegistrationDate { get; set; }

    public DateTime? UpdateDate { get; set; }

    public byte State { get; set; }

    public virtual ICollection<Kardex> Kardices { get; set; } = new List<Kardex>();

    public virtual ICollection<Prescription> Prescriptions { get; set; } = new List<Prescription>();
}
