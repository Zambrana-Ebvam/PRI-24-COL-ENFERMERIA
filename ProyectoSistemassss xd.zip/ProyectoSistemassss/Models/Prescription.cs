﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ProyectoSistemassss.Models;

public partial class Prescription
{

    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    public string Dosage { get; set; } = null!;

    public string Frecuency { get; set; } = null!;

    public string Instructions { get; set; } = null!;

    public DateTime StarDate { get; set; }

    public DateTime EndDate { get; set; }

    public DateTime RegisterDate { get; set; }

    public DateTime? LastUpdate { get; set; }

    public byte Status { get; set; }

    public short MedicineId { get; set; }

    public int NurseId { get; set; }

    public int StudentId { get; set; }

    public virtual Medicine? Medicine { get; set; } 

    public virtual Nurse? Nurse { get; set; } 

    public virtual Student? Student { get; set; } 
}
