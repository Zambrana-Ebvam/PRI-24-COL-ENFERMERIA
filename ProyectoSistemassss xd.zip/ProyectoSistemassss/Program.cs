using Microsoft.EntityFrameworkCore;
using ProyectoSistemassss.Models; // Aseg�rate de cambiar esto a tu espacio de nombres correcto

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddControllersWithViews();


builder.Services.AddDbContext<BdUnivalleEnfermerasContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("SchoolDatabase")));


builder.Services.AddDbContext<BdUnivalleEnfermerasContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("SchoolDatabase")));


var app = builder.Build();


if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}


app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Establishment}/{action=CRUD}/{id?}");

app.Run();
